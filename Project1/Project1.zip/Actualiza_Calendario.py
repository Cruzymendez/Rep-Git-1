# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 14:48:41 2025

@author: cmendez
"""

import sqlite3
from datetime import datetime
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

# ID del calendario
# clpu.es_3hr9hl8jog55ir7bj3148olnbg@group.calendar.google.com


# Conexión a la base de datos SQLite3
db_path = "data2025.sqlite"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Fecha objetivo (jueves 30 de enero de 2025)
fecha_objetivo = "30/01/2025"

# Consultar la tabla CALENDARIO para obtener los datos del día
cursor.execute("SELECT * FROM CALENDARIO WHERE Dia_year = ?", (fecha_objetivo,))
fila = cursor.fetchone()

# Cerrar la conexión a la base de datos
conn.close()

if not fila:
    print("No se encontraron datos para la fecha especificada.")
    exit()

# Asumiendo que las columnas están en el siguiente orden:
columnas = ["Dia_year", "Personas_T1", "Personas_vacaciones", "Personas_baja", 
            "Personas_medico", "Personas_teletrabajo", "Personas_teletrabajo_tarde"]

datos = dict(zip(columnas, fila))

# Extraer datos para el evento
titulo_evento = datos["Personas_T1"]
descripcion = "\n".join([f"{col}: {datos[col]}" for col in columnas[2:] if datos[col]])

# Configurar credenciales de Google Calendar
SCOPES = ["https://www.googleapis.com/auth/calendar"]
CREDENTIALS_FILE = "credentials.json"  # Archivo JSON con credenciales

creds = Credentials.from_service_account_file(CREDENTIALS_FILE, scopes=SCOPES)
service = build("calendar", "v3", credentials=creds)

# Definir los detalles del evento
evento = {
    "summary": titulo_evento,
    "description": descripcion,
    "start": {"date": "2025-01-30"},  # Evento de todo el día
    "end": {"date": "2025-01-31"},
}

# ID del calendario donde se agregará el evento (puede ser "primary" o un ID específico)
CALENDAR_ID = "clpu.es_3hr9hl8jog55ir7bj3148olnbg@group.calendar.google.com"

# Insertar el evento en Google Calendar
evento_creado = service.events().insert(calendarId=CALENDAR_ID, body=evento).execute()
print(f"Evento creado: {evento_creado.get('htmlLink')}")