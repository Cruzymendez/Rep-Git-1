# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 17:23:43 2025

@author: cmendez
"""
import sqlite3
from datetime import datetime, timedelta
import numpy as np
from itertools import combinations

def obtener_dia_actual():
    return datetime.now().strftime("%d/%m/%Y")

def calcular_desviacion(conexion):
    cursor = conexion.cursor()
    cursor.execute("SELECT MNT_M FROM RECUENTO")
    valores = [fila[0] for fila in cursor.fetchall()]
    desviacion = np.std(valores) if valores else 0
    cursor.execute("UPDATE RECUENTO SET DEV_MNT_M = ?", (desviacion,))
    conexion.commit()

def obtener_empleados_disponibles(conexion, excluidos):
    cursor = conexion.cursor()
    cursor.execute("SELECT NOMBRE, ND_T1 FROM EMPLEADOS")
    empleados = sorted(cursor.fetchall(), key=lambda x: x[1])
    empleados_filtrados = [emp[0] for emp in empleados if emp[0] not in excluidos]
    return empleados_filtrados

def actualizar_recuento(conexion, empleados):
    cursor = conexion.cursor()
    for empleado in empleados:
        cursor.execute("UPDATE RECUENTO SET MNT_M = MNT_M + 1 WHERE NOMBRE = ?", (empleado,))
    conexion.commit()
    calcular_desviacion(conexion)

def mejor_combinacion(conexion, empleados_disponibles):
    cursor = conexion.cursor()
    mejor_combo = None
    menor_desviacion = float('inf')
    
    for combo in combinations(empleados_disponibles, 2):
        # Simular la actualización de MNT_M para estos empleados
        cursor.execute("SELECT MNT_M FROM RECUENTO WHERE NOMBRE = ?", (combo[0],))
        result = cursor.fetchone()
        mnt_m1 = (result[0] + 1) if result else 1
        cursor.execute("SELECT MNT_M FROM RECUENTO WHERE NOMBRE = ?", (combo[1],))
        result = cursor.fetchone()
        mnt_m2 = (result[0] + 1) if result else 1
        
        # Obtener todos los valores MNT_M simulados
        cursor.execute("SELECT MNT_M FROM RECUENTO")
        valores_actuales = [fila[0] for fila in cursor.fetchall()]
        valores_actuales.append(mnt_m1)
        valores_actuales.append(mnt_m2)
        
        desviacion_actual = np.std(valores_actuales)
        
        if desviacion_actual < menor_desviacion:
            menor_desviacion = desviacion_actual
            mejor_combo = combo
    
    return mejor_combo if mejor_combo else []


def asignar_turnos(conexion):
    dia_actual = obtener_dia_actual()
    cursor = conexion.cursor()
    cursor.execute("SELECT Dia_year, Modo_trabajo, Personas_vacaciones, Personas_baja, Personas_medico, Personas_teletrabajo FROM CALENDARIO WHERE Dia_year >= ?", (dia_actual,))
    filas = cursor.fetchall()
    
    for fila in filas:
        dia, modo, vac, baja, medico, teletrabajo = fila
        
        if modo != "Mantenimiento":
            continue
        
        excluidos = set()
        for categoria in [vac, baja, medico, teletrabajo]:
            if categoria:
                excluidos.update(categoria.split(","))
        
        empleados_disponibles = obtener_empleados_disponibles(conexion, excluidos)
        seleccionados = mejor_combinacion(conexion, empleados_disponibles)
        
        if not seleccionados:
            asignacion = "NADIE"
        else:
            asignacion = ",".join(seleccionados)
            for empleado in seleccionados:
                cursor.execute("UPDATE EMPLEADOS SET ND_T1 = ND_T1 + 1 WHERE NOMBRE = ?", (empleado,))
            actualizar_recuento(conexion, seleccionados)
        
        cursor.execute("UPDATE CALENDARIO SET Personas_T1 = ? WHERE Dia_year = ?", (asignacion, dia))
    
    conexion.commit()


def obtener_empleados_baja(nombre_bd):
    """
    Obtiene los días y los empleados que están de baja en la tabla CALENDARIO.
    """
    try:
        # Conexión a la base de datos
        conexion = sqlite3.connect(nombre_bd)
        cursor = conexion.cursor()
        # Usar WAL para evitar bloqueos
        cursor.execute("PRAGMA journal_mode=WAL;")
        
        # Consulta para obtener días con empleados de baja
        cursor.execute("""
            SELECT Dia_year, Personas_baja 
            FROM CALENDARIO 
            WHERE Personas_baja IS NOT NULL AND Personas_baja != ''
        """)
        
        # Recopilación de resultados
        resultados = []
        for fila in cursor.fetchall():
            dia, empleados_baja = fila
            empleados = [empleado.strip() for empleado in empleados_baja.split(",")]  # Separar empleados por coma
            resultados.append({"Dia_year": dia, "Empleados_baja": empleados})
        
        # Cerrar la conexión
        conexion.close()
        return resultados

    except sqlite3.Error as e:
        print(f"Error al acceder a la base de datos: {e}")
        return []
    
def obtener_empleados_vacaciones(nombre_bd):
    """
    Obtiene los días y los empleados que están de vacaciones en la tabla CALENDARIO.
    """
    try:
        # Conexión a la base de datos
        conexion = sqlite3.connect(nombre_bd)
        cursor = conexion.cursor()
        # Usar WAL para evitar bloqueos
        cursor.execute("PRAGMA journal_mode=WAL;")
        
        # Consulta para obtener días con empleados de baja
        cursor.execute("""
            SELECT Dia_year, Personas_vacaciones 
            FROM CALENDARIO 
            WHERE Personas_vacaciones IS NOT NULL AND Personas_vacaciones != ''
        """)
        
        # Recopilación de resultados
        resultados = []
        for fila in cursor.fetchall():
            dia, empleados_vacaciones = fila
            empleados = [empleado.strip() for empleado in empleados_vacaciones.split(",")]  # Separar empleados por coma
            resultados.append({"Dia_year": dia, "Empleados_vacaciones": empleados})
        
        # Cerrar la conexión
        conexion.close()
        return resultados

    except sqlite3.Error as e:
        print(f"Error al acceder a la base de datos: {e}")
        return []

def actualizar_nd_baja(nombre_bd, dias_con_bajas):
    """
    Calcula el total de días de baja por empleado y actualiza la tabla EMPLEADOS.

    """
    try:
        # Conexión a la base de datos
        conexion = sqlite3.connect(nombre_bd)
        cursor = conexion.cursor()
        # Usar WAL para evitar bloqueos
        cursor.execute("PRAGMA journal_mode=WAL;")
        
        # Contar días de baja por empleado
        bajas_por_empleado = {}
        for entrada in dias_con_bajas:
            for empleado in entrada["Empleados_baja"]:
                bajas_por_empleado[empleado] = bajas_por_empleado.get(empleado, 0) + 1

        # Actualizar la tabla EMPLEADOS con los días de baja
        for empleado, total_bajas in bajas_por_empleado.items():
            cursor.execute("""
                UPDATE EMPLEADOS
                SET ND_BAJA = ?
                WHERE NOMBRE = ?
            """, (total_bajas, empleado))

        # Guardar cambios y cerrar conexión
        conexion.commit()
        conexion.close()

        print("Tabla EMPLEADOS actualizada con los días de baja.")

    except sqlite3.Error as e:
        print(f"Error al actualizar la base de datos: {e}")
    
def actualizar_nd_vacaciones(nombre_bd, dias_con_vacaciones):
    """
    Calcula el total de días de baja por empleado y actualiza la tabla EMPLEADOS.

    """
    try:
        # Conexión a la base de datos
        conexion = sqlite3.connect(nombre_bd)
        cursor = conexion.cursor()
        # Usar WAL para evitar bloqueos
        cursor.execute("PRAGMA journal_mode=WAL;")
        
        # Contar días de baja por empleado
        vacaciones_por_empleado = {}
        for entrada in dias_con_vacaciones:
            for empleado in entrada["Empleados_vacaciones"]:
                vacaciones_por_empleado[empleado] = vacaciones_por_empleado.get(empleado, 0) + 1

        # Actualizar la tabla EMPLEADOS con los días de baja
        for empleado, total_vacaciones in vacaciones_por_empleado.items():
            cursor.execute("""
                UPDATE EMPLEADOS
                SET ND_VAC = ?
                WHERE NOMBRE = ?
            """, (total_vacaciones, empleado))

        # Guardar cambios y cerrar conexión
        conexion.commit()
        conexion.close()

        print("Tabla EMPLEADOS actualizada con los días de vacaciones.")

    except sqlite3.Error as e:
        print(f"Error al actualizar la base de datos: {e}")


# ACTUALIZACIÓN DE DÍAS DE BAJA:
# dias_con_bajas = obtener_empleados_baja(nombre_base_datos)
# actualizar_nd_baja(nombre_base_datos, dias_con_bajas)

# ACTUALIZACIÓN DE DÍAS DE VACACIONES:
# dias_con_vacaciones = obtener_empleados_vacaciones(nombre_base_datos)
# actualizar_nd_vacaciones(nombre_base_datos, dias_con_vacaciones)

# Conectar a la base de datos y ejecutar el algoritmo
conexion = sqlite3.connect("data2025.sqlite")
asignar_turnos(conexion)
conexion.close()

